Union('sample1.PNG');
Union('sample2.PNG');
Union('sample3.PNG');